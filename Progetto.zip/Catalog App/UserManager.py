import cherrypy
import json

class UserManager():
	exposed = True

	def POST(self, *uri, **params):
		if(len(uri) == 0):
			newuser = json.loads(cherrypy.request.body.read()) # leggo il json nel body del POST
			if('userID' not in newuser or 'name' not in newuser or 'surname' not in newuser or 'email' not in newuser):
				raise cherrypy.HTTPError(400, "Please check your input JSON.")
			if(newuser['userID'] == ""): raise cherrypy.HTTPError(400, "Please check your input UserID.")
			
			with open('Users.txt') as json_file:
				users_data = json.load(json_file)
				if(newuser['userID'] in users_data): raise cherrypy.HTTPError(403, "User Resource \'{}\' is already in database.".format(newuser['userID']))
				users_data[newuser['userID']] = {} # inizializzo una nuova entry nel dizionario	############################
				users_data[newuser['userID']]['userID'] = newuser['userID']
				users_data[newuser['userID']]['name'] = newuser['name']			  			  #	inserisco i dati come object #
				users_data[newuser['userID']]['surname'] = newuser['surname']
				users_data[newuser['userID']]['email'] = newuser['email']						############################

				with open('Users.txt', 'w') as outfile:
					json.dump(users_data, outfile)
				
				return json.dumps(users_data)
		else: raise cherrypy.HTTPError(400, "Invalid URI for a POST request.")

	def GET(self, *uri, **params):
		with open('Users.txt') as json_file:
			users_data = json.load(json_file)
			if(len(uri) == 1 and uri[0] != ""):
				if(uri[0] in users_data):
					search = users_data[uri[0]].copy()
					search = json.dumps(search);
					return search
				else: raise cherrypy.HTTPError(404, "User Resource \'{}\' was not found.".format(uri[0]))

			return json.dumps(users_data)