import cherrypy
import json
import time

class DeviceManager():
	exposed = True
	
	def POST(self, *uri, **params):
		if(len(uri) == 0):
			newdevice = json.loads(cherrypy.request.body.read()) # leggo il json nel body del POST
			if('deviceID' not in newdevice or 'endpoints' not in newdevice or 'resources' not in newdevice):
				raise cherrypy.HTTPError(400, "Please check your input JSON.")
			if(newdevice['deviceID'] == ""): raise cherrypy.HTTPError(400, "Please check your input DeviceID.")

			with open('Devices.txt') as json_file:
				dev_data = json.load(json_file)
				dev_data[newdevice['deviceID']] = {} # inizializzo una nuova entry nel dizionario	############################
				dev_data[newdevice['deviceID']]['deviceID'] = newdevice['deviceID']
				dev_data[newdevice['deviceID']]['endpoints'] = newdevice['endpoints']			###	inserisco i dati come object ###
				dev_data[newdevice['deviceID']]['resources'] = newdevice['resources']
				dev_data[newdevice['deviceID']]['insert-timestamp'] = int(time.time())				############################

				with open('Devices.txt', 'w') as outfile:
					json.dump(dev_data, outfile)

				return json.dumps(dev_data)
		else: raise cherrypy.HTTPError(400, "Invalid URI for a POST request.")

	def GET(self, *uri, **params):
		with open('Devices.txt') as json_file:
			dev_data = json.load(json_file)
			if(len(uri) == 1 and uri[0] != ""):
				if(uri[0] in dev_data):
					search = dev_data[uri[0]].copy()
					search = json.dumps(search);
					return search
				else: raise cherrypy.HTTPError(404, "Device Resource \'{}\' was not found.".format(uri[0]))

			return json.dumps(dev_data)