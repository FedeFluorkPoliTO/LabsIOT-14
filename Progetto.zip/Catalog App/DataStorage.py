import cherrypy
import json
import time
from datetime import datetime

my_base_topic = "tiot/14/"

class DataStorage():
	exposed = True

	def GET(self, *uri, **params):   # GET utilizzate dall'applicazione per accedere allo Storage
		if(len(uri) != 0):
			with open('Storage.txt') as json_file:
				storage = json.load(json_file)
				if(uri[0] == "light"):
					ljson = {}
					ljson = storage['lights']
					return json.dumps(ljson)
				elif(uri[0] == "temperature"):
					tjson = {}
					tjson['temp_avg'] = storage['temp_avg']
					return json.dumps(tjson)
				elif(uri[0] == "emergency"):
					ejson = {}
					ejson = storage['emergencies']
					return json.dumps(ejson)
				elif(uri[0] == "lock"):
					lkjson = {}
					lkjson = storage['locks']
					return json.dumps(lkjson)
				elif(uri[0] == "alarm"):
					ajson = {}
					ajson = storage['alarms']
					return json.dumps(ajson)
		else: raise cherrypy.HTTPError(400, "Invalid URI.")

def on_connect(client, userdata, flags, rc):
	if(rc == 0): 
		print("[MQTT]INFO: Storage connected to broker.")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "deviceadd...")
		client.subscribe(my_base_topic + "deviceadd")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "light...")
		client.subscribe(my_base_topic + "light")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "datain/lock...")
		client.subscribe(my_base_topic + "datain/lock")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "alarm/clock...")
		client.subscribe(my_base_topic + "alarm/clock")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "alarm/alarm...")
		client.subscribe(my_base_topic + "alarm/alarm")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "alarm/delete...")
		client.subscribe(my_base_topic + "alarm/delete")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "datain/emergency...")
		client.subscribe(my_base_topic + "datain/emergency")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "emergency...")
		client.subscribe(my_base_topic + "emergency")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "temp/void...")
		client.subscribe(my_base_topic + "temp/void")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "temp/presence...")
		client.subscribe(my_base_topic + "temp/presence")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "temp...")
		client.subscribe(my_base_topic + "temp")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "presence...")
		client.subscribe(my_base_topic + "presence")
		print("[MQTT]INFO: Subscribing to topic " + my_base_topic + "deviceUpdate...")
		client.subscribe(my_base_topic + "deviceUpdate")
	else: print("[MQTT]ERROR: Storage connection to broker failed.")

def on_message(client, userdata, message):
	mqtt_registration = True
	mqtt_data_storage = True
	doc = json.loads(message.payload)
	if('deviceID' not in doc or 'endpoints' not in doc):
		mqtt_registration = False
	if(mqtt_registration and doc['deviceID'] == ""): 
		mqtt_registration = False
	if('ID' not in doc or 'val' not in doc or 't' not in doc):
		mqtt_data_storage = False
	if(mqtt_data_storage and doc['ID'] == ""): 
		mqtt_data_storage = False
	if(mqtt_registration and not mqtt_data_storage):
		with open('Devices.txt') as json_file:
			dev_data = json.load(json_file)
			dev_data[doc['deviceID']] = {}
			dev_data[doc['deviceID']]['deviceID'] = doc['deviceID']
			dev_data[doc['deviceID']]['endpoints'] = doc['endpoints']
			dev_data[doc['deviceID']]['insert-timestamp'] = int(time.time())
			with open('Devices.txt', 'w') as outfile:
				json.dump(dev_data, outfile)
			print("[MQTT]INFO: \'" + doc['deviceID'] + "\' device added.")
		if(doc['deviceID'] == "alarm0"):
			with open('Storage.txt') as json_file:
				storage = json.load(json_file)
				if(doc['deviceID'] not in storage['alarms']):
					storage['alarms'][doc['deviceID']] = []
					with open('Storage.txt', 'w') as outfile:
						json.dump(storage, outfile)
	elif(mqtt_data_storage and not mqtt_registration):
		doc = json.loads(message.payload)
		with open('Storage.txt') as json_file:
			storage = json.load(json_file)
			if(message.topic == my_base_topic + "light"):
				storage['lights'][doc['ID']] = [doc['val'][0]]
			elif(message.topic == my_base_topic + "datain/lock"):
				storage['locks'][doc['ID']] = [doc['val'][0]]
			elif(message.topic == my_base_topic + "alarm/alarm"):
				if not (doc['ID'] in storage['alarms']):
					storage['alarms'][doc['ID']] = []
				storage['alarms'][doc['ID']].append(doc['val'])
			elif(message.topic == my_base_topic + "alarm/delete"):
				if doc['val'] in storage['alarms'][doc['ID']]:
					storage['alarms'][doc['ID']].pop(storage['alarms'][doc['ID']].index(doc['val']))
			elif(message.topic == my_base_topic + "alarm/clock"):
				for al in storage['alarms'][doc['ID']]:
					dic = {'ID' : doc['ID'], 'val' : al, 't' : int(time.time())}
					if(doc['val'][0] > al[0]):
						client.publish(my_base_topic + "alarm/delete", json.dumps(dic))
					elif(doc['val'][0] == al[0]):
						if(doc['val'][1] > al[1]):
							client.publish(my_base_topic + "alarm/delete", json.dumps(dic))
						elif(doc['val'][1] == al[1]):
							if(doc['val'][2] > al[2]):
								client.publish(my_base_topic + "alarm/delete", json.dumps(dic))
							elif(doc['val'][2] == al[2]):
								if(doc['val'][3] > al[3]):
									client.publish(my_base_topic + "alarm/delete", json.dumps(dic))
								elif(doc['val'][3] == al[3]):
									if(doc['val'][4] > al[4]):
										client.publish(my_base_topic + "alarm/delete", json.dumps(dic))
									elif(doc['val'][4] == al[4]):
										if(doc['val'][5] >= al[5]):
											client.publish(my_base_topic + "alarm/delete", json.dumps(dic))
			elif(message.topic == my_base_topic + "datain/emergency"):
				if not (doc['ID'] in storage['emergencies']):
					storage['emergencies'][doc['ID']] = [None, None]
				storage['emergencies'][doc['ID']][0] = doc['val'][0]
			elif(message.topic == my_base_topic + "emergency"):
				if not (doc['ID'] in storage['emergencies']):
					storage['emergencies'][doc['ID']] = [None, None]
				storage['emergencies'][doc['ID']][1] = doc['val'][0]
			elif(message.topic == my_base_topic + "temp/void"):
				if not (doc['ID'] in storage['temp_set_points']):
					storage['temp_set_points'][doc['ID']] = [None, None]
				storage['temp_set_points'][doc['ID']][0] = doc['val']	
			elif(message.topic == my_base_topic + "temp/presence"):
				if not (doc['ID'] in storage['temp_set_points']):
					storage['temp_set_points'][doc['ID']] = [None, None]
				storage['temp_set_points'][doc['ID']][1] = doc['val']
			elif(message.topic == my_base_topic + "temp"):
				if not (doc['ID'] in storage['temp_noises']):
					storage['temp_noises'][doc['ID']] = [None, None]
				storage['temp_noises'][doc['ID']][0] = doc['val'][0]
				avg = 0.0
				n = 0	
				for t_n in storage['temp_noises']:
					if not(storage['temp_noises'][t_n][0] == None):
						n += 1
						avg += storage['temp_noises'][t_n][0]
				storage['temp_avg'] = avg/n
				dic = {'ID' : doc['ID'], 'val' : [storage['temp_avg']], 't' : int(time.time())}
				client.publish(my_base_topic + "temp/average", json.dumps(dic))
			elif(message.topic == my_base_topic + "presence"):
				if not (doc['ID'] in storage['temp_noises']):
					storage['temp_noises'][doc['ID']] = [None, None]
				storage['temp_noises'][doc['ID']][1] = doc['val'][0]
				p = 0	
				for t_n in storage['temp_noises']:
					if storage['temp_noises'][t_n][1] == 1:
						p = 1
				storage['presence_house'] = p
				dic = {'ID' : doc['ID'], 'val' : [storage['presence_house']], 't' : int(time.time())}
				client.publish(my_base_topic + "presence/house", json.dumps(dic))
			elif(message.topic == my_base_topic + "deviceUpdate"):
				for key in storage:
					if isinstance(storage[key],dict):
						if doc['ID'] in storage[key]:
							if (key == "lights"):
								dic = {'ID' : doc['ID'], 'val' : [storage[key][doc['ID']][0]], 't' : int(time.time())}
								client.publish(my_base_topic + "light", json.dumps(dic))
							elif(key == "alarms"):
								now = datetime.now()
								val_time = [int(now.strftime("%Y")), int(now.strftime("%m")), int(now.strftime("%d")), int(now.strftime("%H")), int(now.strftime("%M")), int(now.strftime("%S"))]
								dic = {'ID' : doc['ID'], 'val' : val_time, 't' : int(time.time())}
								client.publish(my_base_topic + "alarm/clock", json.dumps(dic))
								for al in storage['alarms'][doc['ID']]:
									dic['val'] = al
									dic['t'] = int(time.time())
									client.publish(my_base_topic + "alarm/alarm", json.dumps(dic))
							elif(key == "locks"):
								dic = {'ID' : doc['ID'], 'val' : [storage[key][doc['ID']][0]], 't' : int(time.time())}
								client.publish(my_base_topic + "lock", json.dumps(dic))
							elif(key == "emergencies"):
								dic = {'ID' : doc['ID'], 'val' : [storage[key][doc['ID']][1]], 't' : int(time.time())}
								client.publish(my_base_topic + "emergency", json.dumps(dic))
							elif(key == "temp_set_points"):
								dic = {'ID' : doc['ID'], 'val' : storage[key][doc['ID']][0], 't' : int(time.time())}
								client.publish(my_base_topic + "temp/void", json.dumps(dic))
								dic = {'ID' : doc['ID'], 'val' : storage[key][doc['ID']][1], 't' : int(time.time())}
								client.publish(my_base_topic + "temp/presence", json.dumps(dic))
								dic = {'ID' : doc['ID'], 'val' : [storage['temp_avg']], 't' : int(time.time())}
								client.publish(my_base_topic + "temp/average", json.dumps(dic))
								dic = {'ID' : doc['ID'], 'val' : [storage['presence_house']], 't' : int(time.time())}
								client.publish(my_base_topic + "presence/house", json.dumps(dic))
			with open('Storage.txt', 'w') as outfile:
				json.dump(storage, outfile)
	else: print("[MQTT]ERROR: Invalid input JSON.")