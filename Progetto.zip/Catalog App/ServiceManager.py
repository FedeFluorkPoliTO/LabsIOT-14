import cherrypy
import json
import time

class ServiceManager():
	exposed = True

	def POST(self, *uri, **params):
		if(len(uri) == 0):
			newservice = json.loads(cherrypy.request.body.read()) # leggo il json nel body del POST
			if('serviceID' not in newservice or 'description' not in newservice or 'endpoints' not in newservice):
				raise cherrypy.HTTPError(400, "Please check your input JSON.")
			if(newservice['serviceID'] == ""): raise cherrypy.HTTPError(400, "Please check your input ServiceID.")

			with open('Services.txt') as json_file:
				serv_data = json.load(json_file)
				serv_data[newservice['serviceID']] = {} # inizializzo una nuova entry nel dizionario	############################
				serv_data[newservice['serviceID']]['serviceID'] = newservice['serviceID']
				serv_data[newservice['serviceID']]['description'] = newservice['description']		  #	inserisco i dati come object #
				serv_data[newservice['serviceID']]['endpoints'] = newservice['endpoints']			  
				serv_data[newservice['serviceID']]['insert-timestamp'] = int(time.time())				############################

				with open('Services.txt', 'w') as outfile:
					json.dump(serv_data, outfile)

				return json.dumps(serv_data)
		else: raise cherrypy.HTTPError(400, "Invalid URI for a POST request.")

	def GET(self, *uri, **params):
		with open('Services.txt') as json_file:
			serv_data = json.load(json_file)
			if(len(uri) == 1 and uri[0] != ""):
				if(uri[0] in serv_data):
					search = serv_data[uri[0]].copy()
					search = json.dumps(search);
					return search
				else: raise cherrypy.HTTPError(404, "Service Resource \'{}\' was not found.".format(uri[0]))

			return json.dumps(serv_data)