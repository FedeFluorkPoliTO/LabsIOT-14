import cherrypy
import time
import os.path
from os import path
import paho.mqtt.client as mqtt

from DeviceManager import DeviceManager
from ServiceManager import ServiceManager
from UserManager import UserManager
from DataStorage import *

class BrokerInfo():
	exposed = True

	def GET(self, *uri, **params):
		return json.dumps({
			'ip':"test.mosquitto.org",
			'port':"1883"
		})

if __name__ == '__main__':
	
	if not path.exists("Devices.txt"):   # creo il file che conterra i devices
		with open("Devices.txt", "w") as file:
			file.write("{}")
			print(time.strftime("%H:%M:%S") + " - [Engine]INFO: New file Devices.txt created")
	if not path.exists("Services.txt"):  # creo il file che conterra i services
		with open("Services.txt", "w") as file:
			file.write("{}")
			print(time.strftime("%H:%M:%S") + " - [Engine]INFO: New file Services.txt created")
	if not path.exists("Users.txt"):     # creo il file che conterra gli users
		with open("Users.txt", "w") as file:
			file.write("{}")
			print(time.strftime("%H:%M:%S") + " - [Engine]INFO: New file Users.txt created")
	if not path.exists("Storage.txt"):  # creo il file che conterra il backup per l'app
		with open("Storage.txt", "w") as file:
			file.write("{\"lights\": {}, \"alarms\": {}, \"locks\": {}, \"emergencies\": {}, \"temp_set_points\": {}, \"temp_noises\": {}, \"temp_avg\": null, \"presence_house\": 0}")
			print(time.strftime("%H:%M:%S") + " - [Engine]INFO: New file Storage.txt created")

	conf = {
		'/': {
			'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
			'tools.sessions.on': True
		}
	}
	cherrypy.config.update({'server.socket_host': '0.0.0.0'})
	cherrypy.config.update({'server.socket_port': 8080})
	cherrypy.tree.mount(BrokerInfo(), '/broker', conf)
	cherrypy.tree.mount(DeviceManager(), '/devices', conf)
	cherrypy.tree.mount(ServiceManager(), '/services', conf)
	cherrypy.tree.mount(UserManager(), '/users', conf)
	cherrypy.tree.mount(DataStorage(), '/request', conf)

	broker_address = "test.mosquitto.org"
	print("[MQTT]INFO: Creating new instance...")
	client = mqtt.Client("CatalogMQTT")
	client.on_connect = on_connect # callback in DataStorage.py
	client.on_message = on_message # callback in DataStorage.py
	print("[MQTT]INFO: Connecting to broker...")
	client.connect(broker_address)
	client.loop_start()

	cherrypy.engine.start()
	cherrypy.engine.block()