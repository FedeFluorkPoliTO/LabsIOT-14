package com.example.mqttcontroller;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import helpers.MQTTHelper;
import helpers.MyLocationListener;

public class MainActivity extends AppCompatActivity {
    MQTTHelper mqttHelper;
    TextView dataReceived;
    final MyLocationListener locationListener = new MyLocationListener(MainActivity.this);

    Calendar date; //alarm
    List<String> alarms = new ArrayList<>();
    int lightstate = 0;
    String temperature = "Temperature: XX °C"; //temp
    HashMap<String, Double> temps = new HashMap<>();
    String[] lstate = {"?", "?", "?", "?"}; //lights
    String wstate = "NORMAL"; //emergency
    String gstate = "NORMAL";
    int lockstate = 1; //lock
    boolean uselock = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dataReceived = (TextView) findViewById(R.id.dataReceived);
        dataReceived.setText(temperature);

        startMqtt();

        serverCommunication("all");

        LocationManager locationManager = (LocationManager)
                getSystemService(Context.LOCATION_SERVICE);

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, locationListener);

        // ALARM MANAGEMENT
        ImageButton alarm = (ImageButton) findViewById(R.id.alarm_button);
        alarm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Alarm Management");
                builder.setPositiveButton("Set Current Time", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Date timenow = new Date();
                        String yyy, MMM, ddd, hhh, mmm, sss;
                        SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
                        yyy = formatter.format(timenow);
                        formatter = new SimpleDateFormat("M");
                        MMM = formatter.format(timenow);
                        formatter = new SimpleDateFormat("d");
                        ddd = formatter.format(timenow);
                        formatter = new SimpleDateFormat("H");
                        hhh = formatter.format(timenow);
                        formatter = new SimpleDateFormat("m");
                        mmm = formatter.format(timenow);
                        formatter = new SimpleDateFormat("s");
                        sss = formatter.format(timenow);
                        String json;
                        json = "{\"ID\": \"alarm0\", \"val\": [" + yyy + ", " + MMM + ", " + ddd + ", " + hhh + ", " + mmm + ", " + sss + "], \"t\": " + new Date().getTime() + "}";
                        mqttHelper.publishJSON("tiot/14/alarm/clock", json);
                        Toast.makeText(MainActivity.this, "SUCCESS: Current time set.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("Set Alarm", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        showDateTimePicker();
                    }
                });
                builder.setNeutralButton("Manage Alarms", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setTitle("Manage Alarms");
                        builder.setPositiveButton("View Alarms", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                serverCommunication("alarm");
                                new CountDownTimer(1000, 1000) {
                                    public void onTick(long l) {

                                    }
                                    public void onFinish() {
                                        String body = "";
                                        for(int i=0; i<alarms.size(); i++) {
                                            body += alarms.get(i) + "\n";
                                        }
                                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                        builder.setMessage(body).setTitle("View Alarms");
                                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {

                                            }
                                        });
                                        AlertDialog dialoggg = builder.create();
                                        dialoggg.show();
                                    }
                                }.start();
                            }
                        });
                        builder.setNegativeButton("Delete Alarm", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                serverCommunication("alarm");
                                new CountDownTimer(1000, 1000) {
                                    public void onTick(long l) {

                                    }
                                    public void onFinish() {
                                        final boolean[] afinal = new boolean[alarms.size()];
                                        final boolean[] achecked = new boolean[alarms.size()];
                                        for(int i=0; i<achecked.length; i++) achecked[i] = false;
                                        String[] delalarms = new String[alarms.size()];
                                        alarms.toArray(delalarms);
                                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                        builder.setTitle("Choose alarms to delete:")
                                                .setMultiChoiceItems(delalarms, achecked,
                                                        new DialogInterface.OnMultiChoiceClickListener() {
                                                            @Override
                                                            public void onClick(DialogInterface dialog, int which,
                                                                                boolean isChecked) {
                                                                afinal[which] = isChecked;
                                                            }
                                                        })
                                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int id) {
                                                        String json;
                                                        for(int i=0; i<afinal.length; i++) {
                                                            if(afinal[i]) {
                                                                String[] a1 = alarms.get(i).split(" ");
                                                                String[] hhmm = a1[0].split(":");
                                                                String[] ddMMyyyy = a1[1].split("/");
                                                                json = "{\"ID\": \"alarm0\", \"val\": [" + ddMMyyyy[2] + ", " + ddMMyyyy[1] + ", " + ddMMyyyy[0] + ", " + hhmm[0] + ", " + hhmm[1] + ", 0], \"t\": " + new Date().getTime() + "}";
                                                                mqttHelper.publishJSON("tiot/14/alarm/delete", json);
                                                                Log.w("JSON", json);
                                                            }
                                                        }
                                                        Toast.makeText(MainActivity.this, "INFO: Delete requests sent.", Toast.LENGTH_SHORT).show();
                                                    }
                                                })
                                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int id) {

                                                    }
                                                });
                                        AlertDialog dialoggg = builder.create();
                                        dialoggg.show();
                                    }
                                }.start();
                            }
                        });
                        AlertDialog dialogg = builder.create();
                        dialogg.show();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }

        });

        // LIGHTS MANAGEMENT
        ImageButton lights = (ImageButton) findViewById(R.id.lights_button);
        lights.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String lightmessage = "";
                for(int i=0; i<lstate.length; i++)
                    lightmessage += "light" + i + ": " + lstate[i] + "\n";
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage(lightmessage).setTitle("Lights Management");
                builder.setPositiveButton("Manage", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        final boolean[] lcheckedf = new boolean[lstate.length];
                        String[] l = {"light0", "light1", "light2", "light3"};
                        final boolean[] lchecked = new boolean[lstate.length];
                        for(int i=0; i< lstate.length; i++) {
                            lchecked[i] = lstate[i].equals("ON");
                        }
                        System.arraycopy(lchecked, 0, lcheckedf, 0, lchecked.length);
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setTitle("Choose lights to turn ON")
                                .setMultiChoiceItems(l, lchecked,
                                        new DialogInterface.OnMultiChoiceClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which,
                                                                boolean isChecked) {
                                                lcheckedf[which] = isChecked;
                                            }
                                        })
                                .setPositiveButton("Set", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int id) {
                                        for(int i=0; i<lstate.length; i++)
                                            lstate[i] = "OFF";
                                        for(int i=0; i<lcheckedf.length; i++)
                                            if(lcheckedf[i])
                                                lstate[i] = "ON";
                                        String json;
                                        int state;
                                        for(int i=0; i<lstate.length; i++) {
                                            if(lstate[i].equals("ON"))
                                                state = 1;
                                            else
                                                state = 0;
                                            json = "{\"ID\": \"light" + i + "\", \"val\": [" + state + "], \"t\": " + new Date().getTime() + "}";
                                            mqttHelper.publishJSON("tiot/14/light", json);
                                        }
                                        Toast.makeText(MainActivity.this, "SUCCESS: Lights states set.", Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int id) {

                                    }
                                });
                        AlertDialog dialogg = builder.create();
                        dialogg.show();
                    }
                });
                builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }

        });

        // EMERGENCY MANAGEMENT
        ImageButton emergency = (ImageButton) findViewById(R.id.emergency_button);
        emergency.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                final EditText input = new EditText(MainActivity.this);
                String emergencymessage = "Water Sensor state: " + wstate + "\nGas Sensor state: " + gstate + "\n\nSet Water Sensor threshold:";
                builder.setMessage(emergencymessage).setTitle("Emergency Management");
                builder.setView(input);
                builder.setPositiveButton("Set", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        String json;
                        json = "{\"ID\": \"emergency0\", \"val\": [" + input.getText().toString() + "], \"t\": " + new Date().getTime() + "}";
                        mqttHelper.publishJSON("tiot/14/emergency", json);
                        Toast.makeText(MainActivity.this, "SUCCESS: Water Sensor threshold set.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNeutralButton("Reset Sensors states", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        wstate = "NORMAL";
                        gstate = "NORMAL";
                        Toast.makeText(MainActivity.this, "SUCCESS: Sensors states reset.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }

        });

        // LOCK MANAGEMENT
        ImageButton lock = (ImageButton) findViewById(R.id.lock_button);
        lock.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                String state = "";
                if(lockstate == 1) state = "Closed";
                else if(lockstate == 0) state = "Opened";
                String lockmessage = "Door Lock: " + state + "\n\nWhat would you like to do?";
                builder.setMessage(lockmessage).setTitle("Lock Management");
                builder.setPositiveButton("Set Reference Location", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        locationListener.setLocation();
                        Toast.makeText(MainActivity.this, "SUCCESS: Reference Location for Lock Control set.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("Set Min Distance", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        final EditText input = new EditText(MainActivity.this);
                        input.setInputType(2002);
                        String distmessage = "Set Minimum Distance for Lock Control (in meters):";
                        builder.setMessage(distmessage).setTitle("Lock Management");
                        builder.setView(input);
                        builder.setPositiveButton("Set", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                double mindist = Double.parseDouble(input.getText().toString());
                                locationListener.setMinDist(mindist);
                                Toast.makeText(MainActivity.this, "SUCCESS: Minimum Distance for Lock Control set.", Toast.LENGTH_SHORT).show();
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                            }
                        });
                        AlertDialog dialogg = builder.create();
                        dialogg.show();
                    }
                });
                builder.setNeutralButton("Open/Close Lock", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if(lockstate == 1) {
                            lockstate = 0;
                            String json;
                            json = "{\"ID\": \"lock0\", \"val\": [" + lockstate + "], \"t\": " + new Date().getTime() + "}";
                            mqttHelper.publishJSON("tiot/14/lock", json);
                            Toast.makeText(MainActivity.this, "SUCCESS: Door Lock opened.", Toast.LENGTH_SHORT).show();
                        }
                        else if(lockstate == 0) {
                            lockstate = 1;
                            String json;
                            json = "{\"ID\": \"lock0\", \"val\": [" + lockstate + "], \"t\": " + new Date().getTime() + "}";
                            mqttHelper.publishJSON("tiot/14/lock", json);
                            Toast.makeText(MainActivity.this, "SUCCESS: Door Lock closed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }

        });

        // SETTINGS
        ImageButton settings = (ImageButton) findViewById(R.id.settings_button);
        settings.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Settings");
                builder.setPositiveButton("Temperature Set-Points", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        String tempspmessage = "Select the Set-Points scenario:";
                        builder.setMessage(tempspmessage).setTitle("Temperature Set-Points");
                        builder.setPositiveButton("Without Presence", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                LinearLayout layout = new LinearLayout(MainActivity.this);
                                layout.setOrientation(LinearLayout.VERTICAL);
                                final EditText tmin1 = new EditText(MainActivity.this);
                                tmin1.setInputType(2002);
                                tmin1.setHint("T Min Heater");
                                layout.addView(tmin1);
                                final EditText tmax1 = new EditText(MainActivity.this);
                                tmax1.setInputType(2002);
                                tmax1.setHint("T Max Heater");
                                layout.addView(tmax1);
                                final EditText tmin2 = new EditText(MainActivity.this);
                                tmin2.setInputType(2002);
                                tmin2.setHint("T Min Cooler");
                                layout.addView(tmin2);
                                final EditText tmax2 = new EditText(MainActivity.this);
                                tmax2.setInputType(2002);
                                tmax2.setHint("T Max Cooler");
                                layout.addView(tmax2);
                                builder.setTitle("Temp SP Without Presence");
                                builder.setView(layout);
                                builder.setPositiveButton("Set", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        String json;
                                        json = "{\"ID\": \"cond0\", \"val\": [" + Double.parseDouble(tmin1.getText().toString()) + ", " +
                                                Double.parseDouble(tmax1.getText().toString()) + ", " +
                                                Double.parseDouble(tmin2.getText().toString()) + ", " +
                                                Double.parseDouble(tmax2.getText().toString()) + "], \"t\": " + new Date().getTime() + "}";
                                        mqttHelper.publishJSON("tiot/14/temp/void", json);
                                        Toast.makeText(MainActivity.this, "SUCCESS: Temp SP Without Presence set.", Toast.LENGTH_SHORT).show();
                                    }
                                });
                                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                    }
                                });
                                AlertDialog dialoggg = builder.create();
                                dialoggg.show();
                            }
                        });
                        builder.setNegativeButton("With Presence", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                LinearLayout layout = new LinearLayout(MainActivity.this);
                                layout.setOrientation(LinearLayout.VERTICAL);
                                final EditText tmin1 = new EditText(MainActivity.this);
                                tmin1.setInputType(2002);
                                tmin1.setHint("T Min Heater");
                                layout.addView(tmin1);
                                final EditText tmax1 = new EditText(MainActivity.this);
                                tmax1.setInputType(2002);
                                tmax1.setHint("T Max Heater");
                                layout.addView(tmax1);
                                final EditText tmin2 = new EditText(MainActivity.this);
                                tmin2.setInputType(2002);
                                tmin2.setHint("T Min Cooler");
                                layout.addView(tmin2);
                                final EditText tmax2 = new EditText(MainActivity.this);
                                tmax2.setInputType(2002);
                                tmax2.setHint("T Max Cooler");
                                layout.addView(tmax2);
                                builder.setTitle("Temp SP With Presence");
                                builder.setView(layout);
                                builder.setPositiveButton("Set", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        String json;
                                        json = "{\"ID\": \"temp0\", \"val\": [" + Double.parseDouble(tmin1.getText().toString()) + ", " +
                                                Double.parseDouble(tmax1.getText().toString()) + ", " +
                                                Double.parseDouble(tmin2.getText().toString()) + ", " +
                                                Double.parseDouble(tmax2.getText().toString()) + "], \"t\": " + new Date().getTime() + "}";
                                        mqttHelper.publishJSON("tiot/14/temp/presence", json);
                                        Toast.makeText(MainActivity.this, "SUCCESS: Temp SP With Presence set.", Toast.LENGTH_SHORT).show();
                                    }
                                });
                                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                    }
                                });
                                AlertDialog dialoggg = builder.create();
                                dialoggg.show();
                            }
                        });
                        AlertDialog dialogg = builder.create();
                        dialogg.show();
                    }
                });
                builder.setNegativeButton("Door Lock Settings", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        String[] choices = {"No", "Yes"};
                        String title;
                        if(uselock) title = "Enable Smart Lock? (Actual: Yes)";
                        else title = "Enable Smart Lock? (Actual: No)";
                        builder.setTitle(title)
                        .setItems(choices, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                if(which == 0) {
                                    uselock = false;
                                    Toast.makeText(MainActivity.this, "SUCCESS: GPS-Based Smart Lock disabled.", Toast.LENGTH_SHORT).show();
                                }
                                else if(which == 1) {
                                    uselock = true;
                                    Toast.makeText(MainActivity.this, "SUCCESS: GPS-Based Smart Lock enabled.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                        AlertDialog dialogg = builder.create();
                        dialogg.show();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }

        });
    }

    private void startMqtt() {
        mqttHelper = new MQTTHelper(getApplicationContext());
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
                Log.w("MQTT", "OK " + s);
            }

            @Override
            public void connectionLost(Throwable throwable) {
                Log.w("MQTT", "NOT OK");
            }

            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                Log.w("Debug", mqttMessage.toString());
                switch (topic) {
                    case "tiot/14/datain/light": {
                        String jsonString = mqttMessage.toString();
                        JSONObject jsonobj = new JSONObject(jsonString);
                        int val = jsonobj.getJSONArray("val").getInt(0);
                        switch(jsonobj.getString("ID")) {
                            case "light0":
                                if(val == 1) lstate[0] = "ON";
                                else lstate[0] = "OFF";
                                break;
                            case "light1":
                                if(val == 1) lstate[1] = "ON";
                                else lstate[1] = "OFF";
                                break;
                            case "light2":
                                if(val == 1) lstate[2] = "ON";
                                else lstate[2] = "OFF";
                                break;
                            case "light3":
                                if(val == 1) lstate[3] = "ON";
                                else lstate[3] = "OFF";
                                break;
                        }
                        break;
                    }
                    case "tiot/14/temp/average": {
                        String jsonString = mqttMessage.toString();
                        JSONObject jsonobj = new JSONObject(jsonString);
                        double val = jsonobj.getJSONArray("val").getDouble(0);
                        double tm_2d = (double)Math.round(val * 100d) / 100d;
                        temperature = "Temperature: " + tm_2d + " °C";
                        dataReceived.setText(temperature);
                        break;
                    }
                    case "tiot/14/datain/lock": {
                        String jsonString = mqttMessage.toString();
                        JSONObject jsonobj = new JSONObject(jsonString);
                        lockstate = jsonobj.getJSONArray("val").getInt(0);
                        break;
                    }
                    case "tiot/14/datain/alarm": {
                        String jsonString = mqttMessage.toString();
                        JSONObject jsonobj = new JSONObject(jsonString);
                        lightstate = jsonobj.getJSONArray("val").getInt(0);
                        Date timenow = new Date();
                        final String h, y, m, d;
                        final int dd;
                        SimpleDateFormat formatter = new SimpleDateFormat("H");
                        h = formatter.format(timenow);
                        formatter = new SimpleDateFormat("yyyy");
                        y = formatter.format(timenow);
                        formatter = new SimpleDateFormat("M");
                        m = formatter.format(timenow);
                        formatter = new SimpleDateFormat("d");
                        d = formatter.format(timenow);
                        dd = Integer.parseInt(d) + 1;
                        if(jsonobj.getJSONArray("val").isNull(2)) {
                            if(Integer.parseInt(h) >= 23) {
                                if(lightstate == 0) {
                                    new CountDownTimer(1200000, 1000) {
                                        public void onTick(long l) {
                                            //Log.w("DEBUG", "t: "+ l + " - val: " + lightstate);
                                        }
                                        public void onFinish() {
                                            if(lightstate == 0) {
                                                String json;
                                                json = "{\"ID\": \"alarm0\", \"val\": [" + y + ", " + m + ", " + dd + ", 7, 0, 0], \"t\": " + new Date().getTime() + "}";
                                                mqttHelper.publishJSON("tiot/14/alarm/alarm", json);
                                            }
                                        }
                                    }.start();
                                }
                            }
                        }
                        break;
                    }
                    case "tiot/14/datain/emergency": {
                        String jsonString = mqttMessage.toString();
                        JSONObject jsonobj = new JSONObject(jsonString);
                        String title = "[EMERGENCY]";
                        String body = "";
                        if (jsonobj.getJSONArray("val").getInt(0) == 0) {
                            body = "Water Sensor detected an emergency. (ID: " + jsonobj.getString("ID") + ")";
                            wstate = "EMERGENCY";
                            Log.w("WATER", "Emergency");
                        } else if (jsonobj.getJSONArray("val").getInt(0) == 1) {
                            body = "Gas Sensor detected an emergency. (ID: " + jsonobj.getString("ID") + ")";
                            gstate = "EMERGENCY";
                            Log.w("GAS", "Emergency");
                        }
                        int notifyID = 1;
                        String CHANNEL_ID = "my_channel_01";// The id of the channel.
                        CharSequence name = "Emergency Sensors";// The user-visible name of the channel.
                        int importance = NotificationManager.IMPORTANCE_HIGH;
                        NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
                        Notification notification = new Notification.Builder(MainActivity.this)
                                .setContentTitle(title)
                                .setContentText(body)
                                .setSmallIcon(R.drawable.ic_stat_name)
                                .setChannelId(CHANNEL_ID)
                                .build();
                        NotificationManager mNotificationManager =
                                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                        mNotificationManager.createNotificationChannel(mChannel);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            NotificationChannel channel = new NotificationChannel("my_channel_01",
                                    "Emergency Sensors",
                                    NotificationManager.IMPORTANCE_DEFAULT);
                            mNotificationManager.createNotificationChannel(channel);
                        }
                        mNotificationManager.notify(notifyID , notification);
                        break;
                    }
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {

            }
        });
    }

    public void serverCommunication(final String mode) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url;
                    HttpURLConnection con;
                    if(mode.equals("all")) {
                        url = new URL ("http://10.0.2.2:8080/services"); //register this service
                        con = (HttpURLConnection)url.openConnection();
                        con.setRequestMethod("POST");
                        con.setRequestProperty("Content-Type", "application/json; utf-8");
                        con.setDoOutput(true);
                        JSONObject jsonParam = new JSONObject();
                        jsonParam.put("serviceID", "AndroidMQTTController");
                        jsonParam.put("description", "This service allows you to control your devices with an Android App.");
                        jsonParam.put("endpoints", "Refer to Arduino End-Points");
                        DataOutputStream os = new DataOutputStream(con.getOutputStream());
                        os.writeBytes(jsonParam.toString());
                        os.flush();
                        os.close();
                        Log.i("STATUS", String.valueOf(con.getResponseCode()));
                        Log.i("MSG" , con.getResponseMessage());
                        con.disconnect();
                    }

                    BufferedReader br;
                    StringBuilder sb;
                    String line;
                    String jsonString;
                    JSONObject jsonobj;
                    if(mode.equals("light") || mode.equals("all")) {
                        url = new URL ("http://10.0.2.2:8080/request/light"); //get light sensor states from webserver
                        con = (HttpURLConnection)url.openConnection();
                        con.setRequestMethod("GET");
                        con.setDoOutput(true);
                        con.connect();
                        br = new BufferedReader(new InputStreamReader(url.openStream()));
                        sb = new StringBuilder();
                        while ((line = br.readLine()) != null) {
                            sb.append(line).append("\n");
                        }
                        br.close();
                        jsonString = sb.toString();
                        jsonobj = new JSONObject(jsonString);
                        Log.i("STATUS", String.valueOf(con.getResponseCode()));
                        Log.i("MSG" , con.getResponseMessage());
                        con.disconnect();
                        if(!(jsonobj.equals(new JSONObject()))) {
                            if(jsonobj.getJSONArray("light0").getInt(0) == 1) lstate[0] = "ON";
                            else lstate[0] = "OFF";
                            if(jsonobj.getJSONArray("light1").getInt(0) == 1) lstate[1] = "ON";
                            else lstate[1] = "OFF";
                            if(jsonobj.getJSONArray("light2").getInt(0) == 1) lstate[2] = "ON";
                            else lstate[2] = "OFF";
                            if(jsonobj.getJSONArray("light3").getInt(0) == 1) lstate[3] = "ON";
                            else lstate[3] = "OFF";
                        }
                    }

                    if(mode.equals("temp") || mode.equals("all")) {
                        url = new URL ("http://10.0.2.2:8080/request/temperature"); //get temp sensor states from webserver
                        con = (HttpURLConnection)url.openConnection();
                        con.setRequestMethod("GET");
                        con.setDoOutput(true);
                        con.connect();
                        br = new BufferedReader(new InputStreamReader(url.openStream()));
                        sb = new StringBuilder();
                        while ((line = br.readLine()) != null) {
                            sb.append(line).append("\n");
                        }
                        br.close();
                        jsonString = sb.toString();
                        jsonobj = new JSONObject(jsonString);
                        Log.i("STATUS", String.valueOf(con.getResponseCode()));
                        Log.i("MSG" , con.getResponseMessage());
                        con.disconnect();
                        if(jsonobj.get("temp_avg") != null) {
                            double tm = jsonobj.getDouble("temp_avg");
                            double tm_2d = (double)Math.round(tm * 100d) / 100d;
                            temperature = "Temperature: " + tm_2d + " °C";
                            dataReceived.setText(temperature);
                        }
                    }

                    if(mode.equals("emergency") || mode.equals("all")) {
                        url = new URL ("http://10.0.2.2:8080/request/emergency"); //get emergency sensor states from webserver
                        con = (HttpURLConnection)url.openConnection();
                        con.setRequestMethod("GET");
                        con.setDoOutput(true);
                        con.connect();
                        br = new BufferedReader(new InputStreamReader(url.openStream()));
                        sb = new StringBuilder();
                        while ((line = br.readLine()) != null) {
                            sb.append(line).append("\n");
                        }
                        br.close();
                        jsonString = sb.toString();
                        jsonobj = new JSONObject(jsonString);
                        Log.i("STATUS", String.valueOf(con.getResponseCode()));
                        Log.i("MSG" , con.getResponseMessage());
                        con.disconnect();
                        if(!(jsonobj.equals(new JSONObject()))) {
                            JSONArray keys = jsonobj.names();
                            if(keys != null) {
                                for (int i = 0; i < keys.length(); i++) {
                                    String key = keys.getString(i);
                                    if (!(jsonobj.getJSONArray(key).isNull(0))) {
                                        if (jsonobj.getJSONArray(key).getInt(0) == 0)
                                            wstate = "EMERGENCY";
                                        else if (jsonobj.getJSONArray(key).getInt(0) == 1)
                                            gstate = "EMERGENCY";
                                    }
                                }
                            }
                        }
                    }

                    if(mode.equals("lock") || mode.equals("all")) {
                        url = new URL ("http://10.0.2.2:8080/request/lock"); //get lock sensor states from webserver
                        con = (HttpURLConnection)url.openConnection();
                        con.setRequestMethod("GET");
                        con.setDoOutput(true);
                        con.connect();
                        br = new BufferedReader(new InputStreamReader(url.openStream()));
                        sb = new StringBuilder();
                        while ((line = br.readLine()) != null) {
                            sb.append(line).append("\n");
                        }
                        br.close();
                        jsonString = sb.toString();
                        jsonobj = new JSONObject(jsonString);
                        Log.i("STATUS", String.valueOf(con.getResponseCode()));
                        Log.i("MSG" , con.getResponseMessage());
                        con.disconnect();
                        if(!(jsonobj.equals(new JSONObject()))) lockstate = jsonobj.getJSONArray("lock0").getInt(0);
                    }

                    if(mode.equals("alarm")) {
                        url = new URL ("http://10.0.2.2:8080/request/alarm"); //get alarms from webserver
                        con = (HttpURLConnection)url.openConnection();
                        con.setRequestMethod("GET");
                        con.setDoOutput(true);
                        con.connect();
                        br = new BufferedReader(new InputStreamReader(url.openStream()));
                        sb = new StringBuilder();
                        while ((line = br.readLine()) != null) {
                            sb.append(line).append("\n");
                        }
                        br.close();
                        jsonString = sb.toString();
                        jsonobj = new JSONObject(jsonString);
                        Log.i("STATUS", String.valueOf(con.getResponseCode()));
                        Log.i("MSG" , con.getResponseMessage());
                        con.disconnect();
                        alarms.clear();
                        if(!(jsonobj.equals(new JSONObject()))) {
                            JSONArray alarray = jsonobj.getJSONArray("alarm0");
                            for (int i = 0; i < alarray.length(); i++) {
                                String s = alarray.getJSONArray(i).getInt(3) + ":" + alarray.getJSONArray(i).getInt(4) + " " + alarray.getJSONArray(i).getInt(2) + "/" + alarray.getJSONArray(i).getInt(1) + "/" + alarray.getJSONArray(i).getInt(0);
                                alarms.add(s);
                            }
                        }
                    }

                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }

    public void openLock() {
        if(lockstate == 1 && uselock) {
            lockstate = 0;
            String json;
            json = "{\"ID\": \"lock0\", \"val\": [" + lockstate + "], \"t\": " + new Date().getTime() + "}";
            mqttHelper.publishJSON("tiot/14/lock", json);
        }
    }
    public void checkLock() {
        if(lockstate == 0 && uselock) {
            lockstate = 1;
            String json;
            json = "{\"ID\": \"lock0\", \"val\": [" + lockstate + "], \"t\": " + new Date().getTime() + "}";
            mqttHelper.publishJSON("tiot/14/lock", json);
        }
    }
    public void showDateTimePicker() {
        final Calendar currentDate = Calendar.getInstance();
        date = Calendar.getInstance();
        new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                date.set(year, monthOfYear, dayOfMonth);
                new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        date.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        date.set(Calendar.MINUTE, minute);
                        Log.v("Alarm", "The choosen one " + date.getTime());
                        Date cal = date.getTime();
                        String y, M, d, h, m, s;
                        SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
                        y = formatter.format(cal);
                        formatter = new SimpleDateFormat("M");
                        M = formatter.format(cal);
                        formatter = new SimpleDateFormat("d");
                        d = formatter.format(cal);
                        formatter = new SimpleDateFormat("H");
                        h = formatter.format(cal);
                        formatter = new SimpleDateFormat("m");
                        m = formatter.format(cal);
                        formatter = new SimpleDateFormat("s");
                        s = formatter.format(cal);
                        String json;
                        json = "{\"ID\": \"alarm0\", \"val\": [" + y + ", " + M + ", " + d + ", " + h + ", " + m + ", " + "0], \"t\": " + new Date().getTime() + "}";
                        mqttHelper.publishJSON("tiot/14/alarm/alarm", json);
                        Toast.makeText(MainActivity.this, "SUCCESS: New Alarm set.", Toast.LENGTH_SHORT).show();
                    }
                }, currentDate.get(Calendar.HOUR_OF_DAY), currentDate.get(Calendar.MINUTE), true).show();
            }
        }, currentDate.get(Calendar.YEAR), currentDate.get(Calendar.MONTH), currentDate.get(Calendar.DATE)).show();
    }
}