package helpers;

import android.location.Location;
import android.location.LocationListener;

import com.example.mqttcontroller.MainActivity;

public class MyLocationListener implements LocationListener {

    boolean setLoc;
    double lat1, lng1;
    MainActivity caller;
    double mindist;

    public MyLocationListener(MainActivity ma) {
        setLoc = true;
        caller = ma;
        mindist = 0.1;
    }

    @Override
    public void onLocationChanged(Location location) {
        if(setLoc) {
            lat1 = location.getLatitude();
            lng1 = location.getLongitude();
            setLoc = false;
        }
        else {
            double lat2 = location.getLatitude();
            double lng2 = location.getLongitude();
            if(distance(lat1, lng1, lat2, lng2) < mindist) caller.openLock();
            else caller.checkLock();
        }
    }

    private double distance(double lat1, double lng1, double lat2, double lng2) {
        double earthRadius = 3958.75;
        double dLat = Math.toRadians(lat2-lat1);
        double dLng = Math.toRadians(lng2-lng1);
        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);
        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return earthRadius * c;
    }

    public void setLocation() {
        setLoc = true;
    }

    public void setMinDist(double md) {
        mindist = md*0.0006213712;
    }
}