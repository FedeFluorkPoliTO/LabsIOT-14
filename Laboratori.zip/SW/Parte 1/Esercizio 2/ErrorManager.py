class ErrorManager: 
	def GetError(self, errNum):
		errors = {
        	0: "Uri not setted, please give a command like this /converter/'yourvalue'/'yourunit'/'conversionunit'",
        	1: "Wrong number of params, please set uri like this /converter/'yourvalue'/'yourunit'/'conversionunit'",
        	2: "Web service end-point setted wrong, please start uri like this /conversion",
        	3: "Your value is not a number!",
        	4: "Your original unit was setted wrong, use C for Celsius or K for Kelvin or F for Fahrenheit",
        	5: "Your conversion unit was setted wrong, use C for Celsius or K for Kelvin or F for Fahrenheit",
        	6: "Temperature in Celsius can't be minus of -273.15",
        	7: "Temperature in Kelvin can't be minus of 0",
        	8: "Temperature in Fahrenheit can't be minus of -459,67"
    	}
		return ("Error: " + errors.get(errNum, "Unknown error"))