import cherrypy
import os
import json

class freeboard(object):
	exposed = True
	def GET(self, *uri, **params):
		return open("freeboard/index.html","r").read()

	def POST(self, *uri, **params):
		if uri[0] == "saveDashboard":
			path = "freeboard/dashboard/"
			with open(path + "dashboard.json", "w") as file:
				file.write(params['json_string'])

if __name__ == "__main__":
    conf={
	
	"/":
	{
		'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
		'tools.sessions.on': True,
		'tools.staticdir.root': os.getcwd()
	},
	"/css":
	{
		'tools.staticdir.on':True,
		'tools.staticdir.dir':"freeboard/css"
	},
	"/js":
	{
		'tools.staticdir.on':True,
		'tools.staticdir.dir':"freeboard/js"
	},
	"/img":
	{
		'tools.staticdir.on':True,
		'tools.staticdir.dir':"freeboard/img"
	},
	"/plugins":
	{
		'tools.staticdir.on':True,
		'tools.staticdir.dir':"freeboard/plugins"
	},
	"/dashboard":
	{
		'tools.staticdir.on':True,
		'tools.staticdir.dir':"freeboard/dashboard"
	}
}

cherrypy.config.update({'server.socket_host': '127.0.0.1'})
cherrypy.config.update({'server.socket_port': 8080})
cherrypy.tree.mount(freeboard(), "/", conf)
cherrypy.engine.start()
cherrypy.engine.block()