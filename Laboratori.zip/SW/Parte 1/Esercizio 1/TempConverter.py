import cherrypy
import json

from ErrorManager import *
																				
class Converter(object):
	exposed=True
	def GET(self,*uri,**params):
		error = ErrorManager()
		value = 0
		originalUnit = ""
		targetUnit = ""
		# check error section
		if (len(uri) == 0):
			if (len(params) == 0):
				return error.GetError(0)
			else:
				return error.GetError(1)
		else:
			if (len(params) == 0):
				return error.GetError(2)
			else:
				if(uri[0] != "converter" or len(uri) != 1):
					return error.GetError(3)
				else:
					if(len(params) != 3):
						return error.GetError(4)
					else:
						if(not params.get("value")):
							return error.GetError(5)
						if(not params.get("originalUnit")):
							return error.GetError(6)
						if(not params.get("targetUnit")):
							return error.GetError(7)
						value = params.get("value")
						originalUnit = params.get("originalUnit")
						targetUnit = params.get("targetUnit")
						try:
							float(value)
						except ValueError:
							return error.GetError(8)
						if(originalUnit != "C" and originalUnit != "K" and originalUnit != "F"):
							return error.GetError(9)
						if(targetUnit != "C" and targetUnit != "K" and targetUnit != "F"):
							return error.GetError(10)
		# to json conversion
		jsonDict = {
  			"value": str(round(float(value), 2)),
  			"originalUnit": originalUnit,
  			"convertedValue": self.ConvertValue(value, originalUnit, targetUnit, error),
  			"targetUnit": targetUnit
		}
		jsonFile = json.dumps(jsonDict)
		return jsonFile
	
	def ConvertValue(self, value, originalUnit, targetUnit, error):
		result = value
		if(originalUnit == "C"):
			if(float(value) < -273.15):
				return error.GetError(11)
			if(targetUnit == "K"):
				result = str(round(float(value) + 273.15, 2))
			elif(targetUnit == "F"):
				result = str(round((float(value) * 1.8) + 32, 2))
		elif(originalUnit == "K"):
			if(float(value) < 0):
				return error.GetError(12)
			if(targetUnit == "C"):
				result = str(round(float(value) - 273.15, 2))
			elif(targetUnit == "F"):
				result = str(round((float(value) * 1.8) - 459.67, 2))
		elif(originalUnit == "F"):
			if(float(value) < -459.67):
				return error.GetError(13)
			if(targetUnit == "C"):
				result = str(round((float(value) - 32) / 1.8, 2))
			elif(targetUnit == "K"):
				result = str(round((float(value) + 459.67) / 1.8, 2))
		return result

if __name__ == '__main__':
	conf={
		'/':{
				'request.dispatch':cherrypy.dispatch.MethodDispatcher(),
				'tool.session.on':True
		}
	}
	cherrypy.config.update({'server.socket_host': '127.0.0.1'})
	cherrypy.config.update({'server.socket_port': 8080})
	cherrypy.tree.mount(Converter(),'/',conf)
	cherrypy.engine.start()
	cherrypy.engine.block()