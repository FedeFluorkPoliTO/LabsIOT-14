class ErrorManager: 
	def GetError(self, errNum):
		errors = {
        	0: "Uri and Params not setted, please give a command like this /converter?value='yourvalue'&originalUnit='yourunit'&targetUnit='conversionunit'",
        	1: "Uri not setted, please set uri like this /conversion",
        	2: "Params not setted, please set params like this ?value='yourvalue'&originalUnit='yourunit'&targetUnit='conversionunit'",
        	3: "Uri setted wrong, please set uri like this /conversion",
        	4: "Params number is wrong, please set params like this ?value='yourvalue'&originalUnit='yourunit'&targetUnit='conversionunit'",
        	5: "Key VALUE doesn't exist in Params, please set params like this ?value='yourvalue'&originalUnit='yourunit'&targetUnit='conversionunit'",
        	6: "Key ORIGINALUNIT doesn't exist in Params, please set params like this ?value='yourvalue'&originalUnit='yourunit'&targetUnit='conversionunit'",
        	7: "Key TARGETUNIT doesn't exist in Params, please set params like this ?value='yourvalue'&originalUnit='yourunit'&targetUnit='conversionunit'",
        	8: "VALUE is not a number!",
        	9: "ORIGINALUNIT setted wrong, use C for Celsius or K for Kelvin or F for Fahrenheit",
        	10: "TARGETUNIT setted wrong, use C for Celsius or K for Kelvin or F for Fahrenheit",
        	11: "Temperature in Celsius can't be minus of -273.15",
        	12: "Temperature in Kelvin can't be minus of 0",
        	13: "Temperature in Fahrenheit can't be minus of -459,67"
    	}
		return ("Error: " + errors.get(errNum, "Unknown error"))