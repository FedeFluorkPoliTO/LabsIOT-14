import json
import cherrypy

class TempConverter(object):
	exposed = True

	def PUT(self):
		jsondict = json.loads(cherrypy.request.body.read())

		try:
			jsonf = {
  				"values": jsondict['values'],
  				"originalUnit": jsondict['originalUnit'],
  				"convertedValues": self.convert(jsondict['values'], jsondict['originalUnit'], jsondict['targetUnit']),
  				"targetUnit": jsondict['targetUnit']
			}
			if not jsonf['convertedValues']:
				raise
			jsonput = json.dumps(jsonf)
			return jsonput
		except:
			print("ERROR: Something went wrong, check your JSON input.");
			return

	def convert(self, val, orUnit, taUnit):
		cval = []

		if orUnit == "C":
			if taUnit == "K":
				for x in val:
					cval.append(x+273.15)
			elif taUnit == "F":
				for x in val:
					cval.append((x*1.8)+32)
		elif orUnit == "F":
			if taUnit == "C":
				for x in val:
					cval.append((x-32)*(5/9))
			elif taUnit == "K":
				for x in val:
					cval.append((x+459.67)*(5/9))
		elif orUnit == "K":
			if taUnit == "C":
				for x in val:
					cval.append(x-273.15)
			elif taUnit == "F":
				for x in val:
					cval.append(((x-273.15)*1.8)+32)
					
		return cval

if __name__ == '__main__':
	conf = {
		'/': {
			'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
			'tools.sessions.on': True,
		}
	}
	cherrypy.config.update({'server.socket_host': '127.0.0.1'})
	cherrypy.config.update({'server.socket_port': 8080})
	cherrypy.tree.mount (TempConverter(), '/', conf)
	cherrypy.engine.start()
	cherrypy.engine.block()