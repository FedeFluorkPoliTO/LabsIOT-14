import GetRequest

menu = {}
menu['1'] = " - Visualizza l'indirizzo del Message Broker in uso"
menu['2'] = " - Visualizza tutti i Device"
menu['3'] = " - Cerca un Device"
menu['4'] = " - Visualizza tutti gli User"
menu['5'] = " - Cerca un User"
menu['6'] = " - Visualizza tutti i Service"
menu['7'] = " - Cerca un Service"
menu['8'] = " - Esci"

ok = True
getflag = False

while True:
	ok = True
	getflag = False
	print("\n")
	for i in sorted(menu.keys()):
		print(i + menu[i])
	choice = input("Digita il numero dell'operazione da svolgere: ")
	if(choice == "1"):
		try:
			get = GetRequest.getBroker()
		except:
			print("\n-------------------------------------------------------------")
			print("ERRORE GENERICO: Non è stato possibile ottenere il Message Broker.")
			ok = False
		if(ok):
			getjson = get.json()
			print("\n-------------------------------------------------------------")
			print("Indirizzo del Message Broker in uso: " + getjson['ip'] + ":" + getjson['port'])
		print("-------------------------------------------------------------")
	elif(choice == "2"):
		try:
			get = GetRequest.getDevice()
		except:
			print("\n-------------------------------------------------------------")
			print("ERRORE GENERICO: Non è stato possibile ottenere i Device.")
			ok = False
		if(ok):
			getjson = get.json()
			print("\n-------------------------------------------------------------")
			print("Device registrati:")
			for i in getjson.keys():
				print("- " + getjson[i]['deviceID'])
				getflag = True
			if(not getflag): print("Nessun Device registrato.")
		print("-------------------------------------------------------------")
	elif(choice == "3"):
		search = input("Inserisci l'ID del Device da cercare: ")
		try:
			get = GetRequest.getDevice(search)
		except:
			print("\n-------------------------------------------------------------")
			print("ERRORE GENERICO: Non è stato possibile ottenere il Device.")
			ok = False
		if(ok):
			print("\n-------------------------------------------------------------")
			if(get.status_code != 404):
				getjson = get.json()
				print("- DeviceID: " + getjson['deviceID'])
				print("- End-Points:")
				print(getjson['endpoints'])
				print("- Resources:")
				print(getjson['resources'])
			else: print("ERRORE " + str(get.status_code) + ": Nessun Device registrato con questo ID.")
		print("-------------------------------------------------------------")
	elif(choice == "4"):
		try:
			get = GetRequest.getUser()
		except:
			print("\n-------------------------------------------------------------")
			print("ERRORE GENERICO: Non è stato possibile ottenere gli User.")
			ok = False
		if(ok):
			getjson = get.json()
			print("\n-------------------------------------------------------------")
			print("User registrati:")
			for i in getjson.keys():
				print("- " + getjson[i]['userID'])
				getflag = True
			if(not getflag): print("Nessun User registrato.")
		print("-------------------------------------------------------------")
	elif(choice == "5"):
		search = input("Inserisci l'ID dell'User da cercare: ")
		try:
			get = GetRequest.getUser(search)
		except:
			print("\n-------------------------------------------------------------")
			print("ERRORE GENERICO: Non è stato possibile ottenere l'User.")
			ok = False
		if(ok):
			print("\n-------------------------------------------------------------")
			if(get.status_code != 404):
				getjson = get.json()
				print("- UserID: " + getjson['userID'])
				print("- Name: " + getjson['name'])
				print("- Surname: " + getjson['surname'])
				print("- Email:")
				print(getjson['email'])
			else: print("ERRORE " + str(get.status_code) + ": Nessun User registrato con questo ID.")
		print("-------------------------------------------------------------")
	elif(choice == "6"):
		try:
			get = GetRequest.getService()
		except:
			print("\n-------------------------------------------------------------")
			print("ERRORE GENERICO: Non è stato possibile ottenere i Service.")
			ok = False
		if(ok):
			getjson = get.json()
			print("\n-------------------------------------------------------------")
			print("Service registrati:")
			for i in getjson.keys():
				print("- " + getjson[i]['serviceID'])
				getflag = True
			if(not getflag): print("Nessun Service registrato.")
		print("-------------------------------------------------------------")
	elif(choice == "7"):
		search = input("Inserisci l'ID del Service da cercare: ")
		try:
			get = GetRequest.getService(search)
		except:
			print("\n-------------------------------------------------------------")
			print("ERRORE GENERICO: Non è stato possibile ottenere il Service.")
			ok = False
		if(ok):
			print("\n-------------------------------------------------------------")
			if(get.status_code != 404):
				getjson = get.json()
				print("- ServiceID: " + getjson['serviceID'])
				print("- Description: " + getjson['description'])
				print("- End-Points:")
				print(getjson['endpoints'])
			else: print("ERRORE " + str(get.status_code) + ": Nessun Service registrato con questo ID.")
		print("-------------------------------------------------------------")
	elif(choice == "8"):
		break
	else:
		print("\nComando invalido, riprova.")