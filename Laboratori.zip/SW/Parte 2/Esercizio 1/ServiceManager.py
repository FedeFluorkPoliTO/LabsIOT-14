import cherrypy
import json
import time
import threading

class ServiceManager():
	exposed = True

	def POST(self, *uri, **params):
		if(len(uri) == 0): # 1.8
			newservice = json.loads(cherrypy.request.body.read()) # leggo il json nel body del POST
			if('serviceID' not in newservice or 'description' not in newservice or 'endpoints' not in newservice):
				raise cherrypy.HTTPError(400, "Please check your input JSON.")
			if(newservice['serviceID'] == ""): raise cherrypy.HTTPError(400, "Please check your input ServiceID.")

			with open('Services.txt') as json_file:
				serv_data = json.load(json_file)
				if(newservice['serviceID'] in serv_data): raise cherrypy.HTTPError(403, "Service Resource \'{}\' is already in database.".format(newservice['serviceID']))
				serv_data[newservice['serviceID']] = {} # inizializzo una nuova entry nel dizionario	############################
				serv_data[newservice['serviceID']]['serviceID'] = newservice['serviceID']
				serv_data[newservice['serviceID']]['description'] = newservice['description']		  #	inserisco i dati come object #
				serv_data[newservice['serviceID']]['endpoints'] = newservice['endpoints']			  
				serv_data[newservice['serviceID']]['insert-timestamp'] = int(time.time())				############################

				with open('Services.txt', 'w') as outfile:
					json.dump(serv_data, outfile)

				return json.dumps(serv_data)
		else: raise cherrypy.HTTPError(400, "Invalid URI for a POST request.")

	def GET(self, *uri, **params):
		with open('Services.txt') as json_file:
			serv_data = json.load(json_file)
			if(len(uri) == 1 and uri[0] != ""): # 1.10
				if(uri[0] in serv_data):
					search = serv_data[uri[0]].copy()
					search = json.dumps(search);
					return search
				else: raise cherrypy.HTTPError(404, "Service Resource \'{}\' was not found.".format(uri[0]))

			return json.dumps(serv_data) # 1.9

class Rem_ExpServ(threading.Thread): # ultima richiesta
	def __init__(self, tname):
		threading.Thread.__init__(self)
		self.tname = tname

	def run(self):
		print(time.strftime("%H:%M:%S") + " - [Serv]INFO: Thread " + self.tname + " started.\n")
		while True: # loop infinito
			with open('Services.txt') as json_file:
				serv_data = json.load(json_file)
				temp_data = serv_data.copy() # faccio una copia temporanea del dizionario
				flag = False
				for dev in temp_data.keys(): # itero sulla copia così la dimensione del dizionario originale può cambiare senza problemi
					if((time.time() - temp_data[dev]['insert-timestamp']) > 120): # se creato da più di 2 minuti
						del serv_data[dev] # cancello la entry
						with open('Services.txt', 'w') as outfile:
							json.dump(serv_data, outfile)
						print(time.strftime("%H:%M:%S") + " - [Serv]INFO: Deleted \'" + dev + "\' entry from Services (added " + time.strftime("%H:%M:%S", time.localtime(temp_data[dev]['insert-timestamp'])) + ").\n")
						flag = True
				if(not flag): print(time.strftime("%H:%M:%S") + " - [Serv]INFO: No entries removed.\n")
				time.sleep(60) # aspetto 1 minuto e poi mando il prossimo loop