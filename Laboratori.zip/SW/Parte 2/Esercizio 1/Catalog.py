import cherrypy
import time
import os.path
from os import path

from DeviceManager import *
from ServiceManager import *
from UserManager import UserManager

t_dev = Rem_ExpDev("ExpDevs")		### creo i thread per la ###
t_serv = Rem_ExpServ("ExpServs")	###  rimozione timestamp ###

class BrokerInfo(): # 1.1
	exposed = True

	def GET(self, *uri, **params):
		message_broker = {
			'ip':"test.mosquitto.org",
			'port':"1883"
		}
		return json.dumps(message_broker)

if __name__ == '__main__':

	if not path.exists("Devices.txt"):   # creo il file che conterra i devices
		with open("Devices.txt", "w") as file:
			file.write("{}")
			print(time.strftime("%H:%M:%S") + " - [Engine]INFO: New file Devices.txt created")
	if not path.exists("Services.txt"):  # creo il file che conterra i services
		with open("Services.txt", "w") as file:
			file.write("{}")
			print(time.strftime("%H:%M:%S") + " - [Engine]INFO: New file Services.txt created")
	if not path.exists("Users.txt"):     # creo il file che conterra gli users
		with open("Users.txt", "w") as file:
			file.write("{}")
			print(time.strftime("%H:%M:%S") + " - [Engine]INFO: New file Users.txt created")
		
	t_dev.start()		### thread run all'avvio ###
	t_serv.start()		###     del webserver    ###

	conf = {
		'/': {
			'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
			'tools.sessions.on': True
		}
	}
	cherrypy.config.update({'server.socket_host': '127.0.0.1'})
	cherrypy.config.update({'server.socket_port': 8080})
	cherrypy.tree.mount(BrokerInfo(), '/broker', conf)
	cherrypy.tree.mount(DeviceManager(), '/devices', conf)
	cherrypy.tree.mount(ServiceManager(), '/services', conf)
	cherrypy.tree.mount(UserManager(), '/users', conf)
	cherrypy.engine.start()
	cherrypy.engine.block()