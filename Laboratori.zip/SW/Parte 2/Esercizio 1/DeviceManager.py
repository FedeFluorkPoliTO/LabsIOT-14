﻿import cherrypy
import json
import time
import threading

class DeviceManager():
	exposed = True
	
	def POST(self, *uri, **params):
		if(len(uri) == 0): # 1.2
			newdevice = json.loads(cherrypy.request.body.read()) # leggo il json nel body del POST
			if('deviceID' not in newdevice or 'endpoints' not in newdevice or 'resources' not in newdevice):
				raise cherrypy.HTTPError(400, "Please check your input JSON.")
			if(newdevice['deviceID'] == ""): raise cherrypy.HTTPError(400, "Please check your input DeviceID.")

			with open('Devices.txt') as json_file:
				dev_data = json.load(json_file)
				dev_data[newdevice['deviceID']] = {} # inizializzo una nuova entry nel dizionario	############################
				dev_data[newdevice['deviceID']]['deviceID'] = newdevice['deviceID']
				dev_data[newdevice['deviceID']]['endpoints'] = newdevice['endpoints']			###	inserisco i dati come object ###
				dev_data[newdevice['deviceID']]['resources'] = newdevice['resources']
				dev_data[newdevice['deviceID']]['insert-timestamp'] = int(time.time())				############################

				with open('Devices.txt', 'w') as outfile:
					json.dump(dev_data, outfile)

				return json.dumps(dev_data)
		else: raise cherrypy.HTTPError(400, "Invalid URI for a POST request.")

	def GET(self, *uri, **params):
		with open('Devices.txt') as json_file:
			dev_data = json.load(json_file)
			if(len(uri) == 1 and uri[0] != ""): # 1.4
				if(uri[0] in dev_data):
					search = dev_data[uri[0]].copy()
					search = json.dumps(search);
					return search
				else: raise cherrypy.HTTPError(404, "Device Resource \'{}\' was not found.".format(uri[0]))

			return json.dumps(dev_data) # 1.3

class Rem_ExpDev(threading.Thread): # ultima richiesta
	def __init__(self, tname):
		threading.Thread.__init__(self)
		self.tname = tname

	def run(self):
		print(time.strftime("%H:%M:%S") + " - [Dev]INFO: Thread " + self.tname + " started.\n")
		while True: # loop infinito
			with open('Devices.txt') as json_file:
				dev_data = json.load(json_file)
				temp_data = dev_data.copy() # faccio una copia temporanea del dizionario
				flag = False
				for dev in temp_data.keys(): # itero sulla copia così la dimensione del dizionario originale può cambiare senza problemi
					if((time.time() - temp_data[dev]['insert-timestamp']) > 120): # se creato da più di 2 minuti
						del dev_data[dev] # cancello la entry
						with open('Devices.txt', 'w') as outfile:
							json.dump(dev_data, outfile)
						print(time.strftime("%H:%M:%S") + " - [Dev]INFO: Deleted \'" + dev + "\' entry from Devices (added " + time.strftime("%H:%M:%S", time.localtime(temp_data[dev]['insert-timestamp'])) + ").\n")
						flag = True
				if(not flag): print(time.strftime("%H:%M:%S") + " - [Dev]INFO: No entries removed.\n")
				time.sleep(60) # aspetto 1 minuto e poi mando il prossimo loop