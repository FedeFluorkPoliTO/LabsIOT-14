import cherrypy
import time
import os.path
from os import path
import paho.mqtt.client as mqtt

from DeviceManager import *
from ServiceManager import *
from UserManager import UserManager

t_dev = Rem_ExpDev("ExpDevs")		### creo i thread per la ###
t_serv = Rem_ExpServ("ExpServs")	###  rimozione timestamp ###

class BrokerInfo(): # 1.1
	exposed = True

	def GET(self, *uri, **params):
		return json.dumps({
			'ip':"test.mosquitto.org",
			'port':"1883"
		})

if __name__ == '__main__':
	
	if not path.exists("Devices.txt"):   # creo il file che conterra i devices
		with open("Devices.txt", "w") as file:
			file.write("{}")
			print(time.strftime("%H:%M:%S") + " - [Engine]INFO: New file Devices.txt created")
	if not path.exists("Services.txt"):  # creo il file che conterra i services
		with open("Services.txt", "w") as file:
			file.write("{}")
			print(time.strftime("%H:%M:%S") + " - [Engine]INFO: New file Services.txt created")
	if not path.exists("Users.txt"):     # creo il file che conterra gli users
		with open("Users.txt", "w") as file:
			file.write("{}")
			print(time.strftime("%H:%M:%S") + " - [Engine]INFO: New file Users.txt created")

	t_dev.start()		### thread run all'avvio ###
	t_serv.start()		###     del webserver    ###

	conf = {
		'/': {
			'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
			'tools.sessions.on': True
		}
	}
	cherrypy.config.update({'server.socket_host': '127.0.0.1'})
	cherrypy.config.update({'server.socket_port': 8080})
	cherrypy.tree.mount(BrokerInfo(), '/broker', conf)
	cherrypy.tree.mount(DeviceManager(), '/devices', conf)
	cherrypy.tree.mount(ServiceManager(), '/services', conf)
	cherrypy.tree.mount(UserManager(), '/users', conf)

	broker_address = "test.mosquitto.org"
	print("[MQTT]INFO: Creating new instance...")
	client = mqtt.Client("CatalogMQTT")
	client.on_connect = on_connect # callback in DeviceManager.py
	client.on_message = on_message # callback in DeviceManager.py
	print("[MQTT]INFO: Connecting to broker...")
	client.connect(broker_address)
	client.loop_start()
	print("[MQTT]INFO: Subscribing to topic tiot/14/deviceadd...")
	client.subscribe("tiot/14/deviceadd")

	cherrypy.engine.start()
	cherrypy.engine.block()