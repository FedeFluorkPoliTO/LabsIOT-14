import paho.mqtt.client as PahoMQTT
import time
import json

def on_connect (client, userdata, flags, rc):
	if(rc == 0): print("[MQTT]INFO: Connected to %s with result code: %d" % (self.messageBroker, rc))
	else: print("[MQTT]ERROR: Connection to broker failed.")

def on_publish(client, userdata, result):
   	print("[MQTT]INFO: Data published ")
   	print(message.payload)

updateTime = 5  # frequenza di invio in secondi
broker_address = "test.mosquitto.org"
broker_port = 1883

device = PahoMQTT.Client("IOT Device", False)
device.on_connect = on_connect
device.on_publish = on_publish
print(f"[MQTT]INFO: Connecting to broker {broker_address}")
device.connect(broker_address, broker_port)
device.loop_start()
while True:
	print("\n")
	newDevice = {
					"deviceID": "Samsung",
					"endpoints": ["/devices/prova", "/devices/download", "devices/samsung"],
					"resources": ["TempSensor", "MovSensor", "Gyroscope"]
				}
	print("[MQTT]INFO: Publishing to topic tiot/14/deviceadd...")
	device.publish("tiot/14/deviceadd", json.dumps(newDevice)) 	
	time.sleep(updateTime)
