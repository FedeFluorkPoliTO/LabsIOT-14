import time
import requests

updateTime = 60  # frequenza di invio in secondi

while True:
	print("\n")
	newDevice = {
					"deviceID": "Samsung",
					"endpoints": ["/devices/prova", "/devices/download", "devices/samsung"],
					"resources": ["TempSensor", "MovSensor", "Gyroscope"]
				}
	r = requests.post('http://localhost:8080/devices', json = newDevice)
	if(r.status_code == 200):
		print("Device Posted: ")
		for key,value in newDevice.items():
			print(f"\t{key}: {value}")
	else:
		print(f"Error occurred with status code {r.status_code}")
	time.sleep(updateTime)