import json
import time
import GetRequest
import paho.mqtt.client as mqtt

thisService = {
	'serviceID': "SHController",
	'description': "This service allows you to control a Smart Home Device.",
	'endpoints': ""
}

getEndpoints = {
	'getvalues': [],
	'setvalues': [],
}

my_base_topic = "tiot/14/"

actualTemp = 0.0
presence = 0
fan_setpoints = [[40.0, 45.0], [28.0, 30.0]]
led_setpoints = [[26.0, 30.0], [15.0, 20.0]]

menu = {}
menu['1'] = " - Inserisci manualmente dei setpoints"
menu['2'] = " - Invia un messaggio sul display"
menu['3'] = " - Esci"

def set_FanLed():
	mqtt_values = {
		"actuator": "fan",
		"value": linProp(actualTemp, fan_setpoints[presence][0], fan_setpoints[presence][1], 0, 255)
	}
	for topic in getEndpoints['setvalues']:
		if(topic == (my_base_topic + "fan")):
			client.publish(topic, json.dumps(mqtt_values))
	mqtt_values = {
		"actuator": "led",
		"value": linProp(actualTemp, led_setpoints[presence][0], led_setpoints[presence][1], 255, 0)
	}
	for topic in getEndpoints['setvalues']:
		if(topic == (my_base_topic + "led")):
			client.publish(topic, json.dumps(mqtt_values))

def linProp(x, in_min, in_max, out_min, out_max):
  	value = int((x - in_min) * float(out_max - out_min) / (in_max - in_min)) + out_min
  	if (out_min > out_max):
  		if(value > out_min):
  			return out_min
  		if(value < out_max):
  			return out_max
  	else:
  		if(value < out_min):
  			return out_min
  		elif(value > out_max):
  			return out_max
  	return value

def on_connect(client, userdata, flags, rc):
	if(rc == 0):
		print("[MQTT]INFO: Connessione riuscita.")
		print("[MQTT]INFO: Digita CTRL+C per disconnetterti.")

		for s in getEndpoints['getvalues']:
			client.subscribe(s)
			print(f"[MQTT]INFO: Subscribe -> {s}")
		
	else:
		print("[MQTT]ERRORE: Connessione fallita. Chiusura dello script in 3 secondi.")
		time.sleep(3)
		quit()

def on_message(client, userdata, message):
	global actualTemp
	global presence
	mqtt_get = json.loads(message.payload)
	if(mqtt_get["e"][0]["n"] == "temperature"):
		actualTemp = float(mqtt_get["e"][0]["v"])
	if(mqtt_get["e"][0]["n"] == "pres"):
		presence = int(mqtt_get["e"][0]["v"])
	set_FanLed()

input_device = input("Inserisci l'ID del Device da usare: ")
get = GetRequest.getDevice(input_device)
while(get.status_code != 200):
	print(f"ERRORE {get.status_code}: Non è stato possibile ottenere il Device. Riprova.")
	input_device = input("Inserisci l'ID del Device da usare: ")
	get = GetRequest.getDevice(input_device)
print(f"INFO: Device trovato: \'{input_device}\'.")
thisService['endpoints'] = (get.json())['endpoints']

for topic in thisService['endpoints'][0]:
	getEndpoints['getvalues'].append(my_base_topic + topic)
for topic in thisService['endpoints'][1]:
	getEndpoints['setvalues'].append(my_base_topic + topic)

print("INFO: Registro questo Service nel Catalog...")
post = GetRequest.addService(thisService)
if(post.status_code == 200):
	print("INFO: Service registrato con successo.")
	get = GetRequest.getBroker()
	if(get.status_code == 200):
		print("INFO: Message Broker ottenuto con successo. Connessione...")
		broker_address = (get.json())['ip']
		client = mqtt.Client("SHController")
		client.on_connect = on_connect
		client.on_message = on_message
		client.connect(broker_address)
		client.loop_start()
		time.sleep(2)
		while True:
			for i in sorted(menu.keys()):
				print(i + menu[i])
			choice = input("\nDigita il numero dell'operazione da svolgere: ")
			if(choice == "1"):
				fan_setpoints[0][0] = input("Minimo setpoint cooler senza presenza (float): ")
				fan_setpoints[0][1] = input("Massimo setpoint cooler senza presenza (float): ")
				fan_setpoints[1][0] = input("Minimo setpoint cooler con presenza (float): ")
				fan_setpoints[1][1] = input("Massimo setpoint cooler con presenza (float): ")
				led_setpoints[0][0] = input("Minimo setpoint heater senza presenza (float): ")
				led_setpoints[0][1] = input("Massimo setpoint heater senza presenza (float): ")
				led_setpoints[1][0] = input("Minimo setpoint heater con presenza (float): ")
				led_setpoints[1][1] = input("Massimo setpoint heater con presenza (float): ")
				print("INFO: Nuovi setpoints impostati.\n")
			elif(choice == "2"):
				lcdmessage = input("Digita il messaggio da inviare al display: ")
				mqtt_lcdmessage = {
					"actuator": "lcd",
					"value": lcdmessage
				}
				for topic in getEndpoints['setvalues']:
					if(topic == (my_base_topic + "lcd")):
						client.publish(topic, json.dumps(mqtt_lcdmessage))
				print("INFO: Messaggio inviato.\n")
			elif(choice == "3"):
				break
			else:
				print("Comando invalido, riprova.\n")
	else:   
		print(f"ERRORE {get.status_code}: Non è stato possibile ottenere il Message Broker.")
else:
	print(f"ERRORE {post.status_code}: Non è stato possibile registrare il Service.")