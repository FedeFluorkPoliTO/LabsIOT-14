import json
import time
import GetRequest
import paho.mqtt.client as mqtt

thisService = {
	'serviceID': "MQTT_TempSubscriber",
	'description': "This service subscribe to a topic and get the temperature sent by a device.",
	'endpoints': ""
}

def on_connect(client, userdata, flags, rc):
	if(rc == 0):
		print("[MQTT]INFO: Connessione riuscita.")
		print("[MQTT]INFO: Digita CTRL+C per disconnetterti.")
		if(isinstance(thisService['endpoints'], list)):
			for ep in thisService['endpoints']:
				client.subscribe(ep)
				print(f"[MQTT]INFO: Subscribe -> {ep}")
		else:
			client.subscribe(thisService['endpoints'])
			print(f"[MQTT]INFO: Subscribe -> {thisService['endpoints']}")
		
	else:
		print("[MQTT]ERRORE: Connessione fallita. Chiusura dello script in 3 secondi.")
		time.sleep(3)
		quit()

def on_message(client, userdata, message):
	mqtt_getTemp = json.loads(message.payload)
	print(f"[MQTT]{mqtt_getTemp['bn']} - Temperatura rilevata: {mqtt_getTemp['e'][0]['v']} {mqtt_getTemp['e'][0]['u']}")

input_device = input("Inserisci l'ID del Device da usare: ")
get = GetRequest.getDevice(input_device)
while(get.status_code != 200):
	print(f"ERRORE {get.status_code}: Non è stato possibile ottenere il Device. Riprova.")
	input_device = input("Inserisci l'ID del Device da usare: ")
	get = GetRequest.getDevice(input_device)
print(f"INFO: Device trovato: \'{input_device}\'.")
thisService['endpoints'] = (get.json())['endpoints']
print("INFO: Registro questo Service nel Catalog...")
post = GetRequest.addService(thisService)
if(post.status_code == 200):
	print("INFO: Service registrato con successo.")
	get = GetRequest.getBroker()
	if(get.status_code == 200):
		print("INFO: Message Broker ottenuto con successo. Connessione...")
		broker_address = (get.json())['ip']
		client = mqtt.Client("TempSubscriber")
		client.on_connect = on_connect
		client.on_message = on_message
		client.connect(broker_address)
		client.loop_start()
		try:
   			while True:
   				time.sleep(1)
		except KeyboardInterrupt: # premendo CTRL+C puoi interrompere lo script
   			print("INFO: Disconnessione in corso...")
   			client.disconnect()
   			client.loop_stop()
	else:
   		print(f"ERRORE {get.status_code}: Non è stato possibile ottenere il Message Broker.")
else:
	print(f"ERRORE {post.status_code}: Non è stato possibile registrare il Service.")