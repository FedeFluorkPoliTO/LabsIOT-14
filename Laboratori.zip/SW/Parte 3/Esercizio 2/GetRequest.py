import requests

def url(path):
	return "http://127.0.0.1:8080/" + path;

def getBroker():
	return requests.get(url("broker"))

def getDevice(devID=""):
	return requests.get(url("devices/" + devID))

def addService(serviceJSON):
	return requests.post(url("services/"), json=serviceJSON)