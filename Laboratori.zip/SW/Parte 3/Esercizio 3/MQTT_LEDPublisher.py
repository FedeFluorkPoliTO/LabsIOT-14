import json
import time
import GetRequest
import paho.mqtt.client as mqtt

thisService = {
	'serviceID' : "MQTT_LEDPublisher",
	'description' : "This service publish to a topic and set device LED on/off.",
	'endpoints' : ""
}

thisJsonToPub = {
	"bn" : "Yun",
	"e" : [{
		"t" : 0,
		"n" : "led",
		"v" : 0,
		"u" : ""
	}]
}

publishTopic = "tiot/14/led" # topic in cui pubblicare

def on_connect(client, userdata, flags, rc):
	if(rc == 0):
		print("[MQTT]INFO: Connessione riuscita.")
		print("[MQTT]INFO: Digita CTRL+C per disconnetterti.")
		if publishTopic in thisService['endpoints']:
			print(f"[MQTT]INFO: Il topic {publishTopic} esiste per questo device")
		else:
			print(f"[MQTT]ERRORE: Il topic {publishTopic} non esiste per questo device. Chiusura dello script in 3 secondi.")
			time.sleep(3)
			quit()
	else:
		print("[MQTT]ERRORE: Connessione fallita. Chiusura dello script in 3 secondi.")
		time.sleep(3)
		quit()

def on_publish(client, userdata, result):
   	print("[MQTT]INFO: Data published ")
   	print(message.payload)

input_device = input("Inserisci l'ID del Device da controllare: ")
get = GetRequest.getDevice(input_device)
while(get.status_code != 200):
	print(f"ERRORE {get.status_code}: Non è stato possibile ottenere il Device. Riprova.")
	input_device = input("Inserisci l'ID del Device da usare: ")
	get = GetRequest.getDevice(input_device)
print(f"INFO: Device trovato: \'{input_device}\'.")
thisService['endpoints'] = (get.json())['endpoints']
print("INFO: Registro questo Service nel Catalog...")
post = GetRequest.addService(thisService)
if(post.status_code == 200):
	print("INFO: Service registrato con successo.")
	get = GetRequest.getBroker()
	if(get.status_code == 200):
		print("INFO: Message Broker ottenuto con successo. Connessione...")
		broker_address = (get.json())['ip']
		client = mqtt.Client("LEDPublisher")
		client.on_connect = on_connect
		client.on_publish = on_publish
		client.connect(broker_address)
		client.loop_start()
		time.sleep(2)
		try:
   			while True:
   				ledNewState = input("Scrivi 1 per accendere il LED o 0 per spegnerlo : ")
   				if (ledNewState == "0" or ledNewState == "1"):
   					thisJsonToPub["e"][0]["v"] = int(ledNewState)
   					thisJsonToPub["e"][0]["t"] = int(time.time())
   					client.publish(publishTopic, json.dumps(thisJsonToPub))
   				else:
   					print("ERRORE: Il valore inserito non è riconosciuto. Riprova.")
		except KeyboardInterrupt: # premendo CTRL+C puoi interrompere lo script
   			print("INFO: Disconnessione in corso...")
   			client.disconnect()
   			client.loop_stop()
	else:
   		print(f"ERRORE {get.status_code}: Non è stato possibile ottenere il Message Broker.")
else:
	print(f"ERRORE {post.status_code}: Non è stato possibile registrare il Service.")