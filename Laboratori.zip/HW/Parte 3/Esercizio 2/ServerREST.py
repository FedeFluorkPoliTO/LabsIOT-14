import cherrypy
import json
																				
class ArduinoService(object):
	exposed=True
	def __init__(self):
		self.body = []

	def GET(self,*uri,**params):
		return self.body
			
	def POST(self,*uri,**params):
		tempJson = json.loads(cherrypy.request.body.read())
		self.body.append(json.dumps(tempJson))
		return self.body 

if __name__ == '__main__':
	conf={
		'/':{
				'request.dispatch':cherrypy.dispatch.MethodDispatcher(),
				'tool.session.on':True
		}
	}
	cherrypy.config.update({'server.socket_host':  '127.0.0.1'})
	cherrypy.config.update({'server.socket_port':8080})
	cherrypy.tree.mount(ArduinoService(),'/log',conf)
	cherrypy.engine.start()
	cherrypy.engine.block()